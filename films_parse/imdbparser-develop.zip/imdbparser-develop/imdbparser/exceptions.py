class IMDbException(Exception):
    pass


class UnknownChartTypeException(IMDbException):
    pass
