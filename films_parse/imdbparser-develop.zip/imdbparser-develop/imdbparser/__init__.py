from .imdb import AS, IMDb  # NOQA

__version__ = "1.0.22"
